//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cp5Vs3Ii.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/play",
			"/api/rtc"
		],
		preloads: [
			"/assets/index-E1JIR9vg.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/identity-BruuIMYC.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-E1JIR9vg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CmMQxLD9.js", "/assets/audio-BO5F4Xb7.js"]
	},
	"/play": {
		filePath: "/workspace/src/routes/play.tsx",
		children: void 0,
		preloads: ["/assets/play-jKSauAf0.js", "/assets/audio-BO5F4Xb7.js"]
	}
} });
//#endregion
export { tsrStartManifest };
