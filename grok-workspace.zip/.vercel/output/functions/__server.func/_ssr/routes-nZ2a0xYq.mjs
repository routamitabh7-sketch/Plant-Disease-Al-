import { o as __toESM } from "../_runtime.mjs";
import { a as sanitizeCode, n as loadName, r as makeTableCode, s as saveName } from "./identity-BlYKLsRG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as unlockAudio, i as attachUnlockOnce, n as Input, r as WickMark, t as Button } from "./audio-C_fTGywk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-nZ2a0xYq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LandingView() {
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("Guest");
	const [code, setCode] = (0, import_react.useState)("");
	const [joinError, setJoinError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setName(loadName());
		attachUnlockOnce();
	}, []);
	function persist() {
		const next = name.trim().slice(0, 24) || "Guest";
		setName(next);
		saveName(next);
		unlockAudio();
		return next;
	}
	function createTable() {
		persist();
		const table = makeTableCode();
		navigate({
			to: "/play",
			search: { room: table }
		});
	}
	function practice() {
		persist();
		navigate({
			to: "/play",
			search: { solo: true }
		});
	}
	function joinTable(e) {
		e.preventDefault();
		const next = sanitizeCode(code);
		if (next.length !== 4) {
			setJoinError("Enter the four-character table code.");
			return;
		}
		persist();
		navigate({
			to: "/play",
			search: { room: next }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative mx-auto flex min-h-dvh w-full max-w-lg flex-col px-5 py-8 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-x-0 top-0 h-64 wick-wash",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WickMark, { className: "h-12 w-6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-6xl font-medium italic leading-none tracking-tight text-fg sm:text-7xl",
					children: "Wick"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-base leading-relaxed text-muted",
					children: "A word, before it burns. Sit a table with friends, or practice against the house."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-10 text-xs font-medium tracking-widest text-muted uppercase",
					htmlFor: "wick-name",
					children: "Your name"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "wick-name",
					className: "mt-2",
					value: name,
					maxLength: 24,
					onChange: (e) => setName(e.target.value),
					autoComplete: "nickname"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: createTable,
						children: "Create a table"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						onClick: practice,
						children: "Practice with the house"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: joinTable,
					className: "mt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Join with a code"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: code,
								onChange: (e) => {
									setCode(sanitizeCode(e.target.value));
									setJoinError(null);
								},
								placeholder: "A7KM",
								autoCapitalize: "characters",
								autoCorrect: "off",
								spellCheck: false,
								"aria-label": "Table code",
								className: "font-display tracking-code uppercase"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "secondary",
								children: "Sit"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 min-h-5 text-sm text-fuse",
							children: joinError ?? " "
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-auto space-y-3 pt-10 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "1."
						}), " Letters appear in the ring."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "2."
						}), " Type a dictionary word that contains them."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "3."
						}), " Miss and you lose a life. Last wick lit wins."] })
					]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingView, {});
}
//#endregion
export { Home as component };
