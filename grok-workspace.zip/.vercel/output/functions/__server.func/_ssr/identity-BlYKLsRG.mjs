//#region node_modules/.nitro/vite/services/ssr/assets/identity-BlYKLsRG.js
var NAME_KEY = "wick:name";
var MUTE_KEY = "wick:mute";
var CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function loadName() {
	if (typeof window === "undefined") return "Guest";
	const saved = localStorage.getItem(NAME_KEY)?.trim();
	if (saved) return saved.slice(0, 24);
	return `Guest ${Math.floor(10 + Math.random() * 90)}`;
}
function saveName(name) {
	if (typeof window === "undefined") return;
	localStorage.setItem(NAME_KEY, name.trim().slice(0, 24));
}
function loadMuted() {
	if (typeof window === "undefined") return false;
	return localStorage.getItem(MUTE_KEY) === "1";
}
function saveMuted(muted) {
	if (typeof window === "undefined") return;
	localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
}
function makeTableCode() {
	let code = "";
	for (let i = 0; i < 4; i++) code += CODE_ALPHABET[Math.floor(Math.random() * 32)];
	return code;
}
function sanitizeCode(raw) {
	return raw.toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/[O]/g, "0").replace(/[I]/g, "1").slice(0, 4);
}
function roomIdForCode(code) {
	return `wick-${code}`;
}
//#endregion
export { sanitizeCode as a, roomIdForCode as i, loadName as n, saveMuted as o, makeTableCode as r, saveName as s, loadMuted as t };
