import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audio-C_fTGywk.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors transition-transform duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40 active:scale-95 min-h-11", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "border border-border bg-elevated text-fg hover:border-fg/25",
			ghost: "text-muted hover:bg-elevated hover:text-fg",
			danger: "border border-fuse/30 bg-fuse/15 text-fuse hover:bg-fuse/25"
		},
		size: {
			default: "h-11 px-5",
			lg: "h-12 px-6 text-base",
			sm: "h-9 min-h-9 px-3 text-sm",
			icon: "size-11 p-0"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-elevated px-3 text-base text-fg placeholder:text-subtle", "transition-colors duration-150 ease-out", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", "disabled:opacity-40", className),
		...props
	});
}
function WickMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 40",
		"aria-hidden": "true",
		className: cn("text-accent", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 38 V14",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5",
			strokeLinecap: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 14 C12 10 9.5 8 10 5 C11.5 7 13.5 6.5 14 4 C15.5 8 12 10 12 14 Z",
			fill: "currentColor",
			className: "text-fuse"
		})]
	});
}
var ctx = null;
var master = null;
var muted = false;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		ctx = new AC({ latencyHint: "interactive" });
		master = ctx.createGain();
		master.gain.value = muted ? 0 : .22;
		master.connect(ctx.destination);
	}
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function unlockAudio() {
	const c = getCtx();
	if (c?.state === "suspended") c.resume();
}
function setMuted(next) {
	muted = next;
	if (master && ctx) master.gain.setTargetAtTime(next ? 0 : .22, ctx.currentTime, .03);
}
function tone(freq, dur, type, gain = .18, at = 0) {
	const c = getCtx();
	if (!c || !master) return;
	const osc = c.createOscillator();
	const g = c.createGain();
	osc.type = type;
	osc.frequency.value = freq;
	const t0 = c.currentTime + at;
	g.gain.setValueAtTime(1e-4, t0);
	g.gain.exponentialRampToValueAtTime(gain, t0 + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
	osc.connect(g);
	g.connect(master);
	osc.start(t0);
	osc.stop(t0 + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
function noise(dur, gain = .12) {
	const c = getCtx();
	if (!c || !master) return;
	const buffer = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
	const src = c.createBufferSource();
	src.buffer = buffer;
	const g = c.createGain();
	const f = c.createBiquadFilter();
	f.type = "lowpass";
	f.frequency.value = 900;
	const t0 = c.currentTime;
	g.gain.setValueAtTime(gain, t0);
	g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
	src.connect(f);
	f.connect(g);
	g.connect(master);
	src.start(t0);
	src.stop(t0 + dur + .02);
}
function playTick() {
	tone(880 + Math.random() * 40, .05, "square", .06);
}
function playOk() {
	tone(523, .09, "sine", .14);
	tone(784, .12, "sine", .1, .07);
}
function playFail() {
	tone(140, .18, "sawtooth", .1);
	noise(.16, .08);
}
function playBoom() {
	noise(.28, .16);
	tone(90, .22, "sine", .18);
}
function playWin() {
	tone(523, .12, "sine", .12);
	tone(659, .12, "sine", .12, .1);
	tone(784, .18, "sine", .12, .2);
}
function attachUnlockOnce() {
	if (typeof window === "undefined") return;
	const unlock = () => unlockAudio();
	window.addEventListener("pointerdown", unlock, { once: true });
	window.addEventListener("keydown", unlock, { once: true });
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") unlockAudio();
	});
}
//#endregion
export { cn as a, playOk as c, setMuted as d, unlockAudio as f, attachUnlockOnce as i, playTick as l, Input as n, playBoom as o, WickMark as r, playFail as s, Button as t, playWin as u };
