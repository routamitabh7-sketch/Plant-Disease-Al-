const NAME_KEY = "wick:name";
const MUTE_KEY = "wick:mute";
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function loadName(): string {
  if (typeof window === "undefined") return "Guest";
  const saved = localStorage.getItem(NAME_KEY)?.trim();
  if (saved) return saved.slice(0, 24);
  return `Guest ${Math.floor(10 + Math.random() * 90)}`;
}

export function saveName(name: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(NAME_KEY, name.trim().slice(0, 24));
}

export function loadMuted(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(MUTE_KEY) === "1";
}

export function saveMuted(muted: boolean): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
}

export function makeTableCode(): string {
  let code = "";
  for (let i = 0; i < 4; i++) {
    code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return code;
}

export function sanitizeCode(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .replace(/[O]/g, "0")
    .replace(/[I]/g, "1")
    .slice(0, 4);
}

export function roomIdForCode(code: string): string {
  return `wick-${code}`;
}
