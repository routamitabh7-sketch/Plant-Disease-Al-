import { useEffect, useRef } from "react";
import { playBoom, playFail, playOk, playTick, playWin } from "./audio";
import type { GameState } from "./types";

export function useWickJuice(state: GameState | null) {
  const nonce = useRef(0);
  const lastSecond = useRef<number | null>(null);

  useEffect(() => {
    if (!state) return;
    if (state.eventNonce !== nonce.current) {
      nonce.current = state.eventNonce;
      const kind = state.lastEvent?.kind;
      if (kind === "ok") playOk();
      else if (kind === "fail") playFail();
      else if (kind === "timeout" || kind === "out") playBoom();
      else if (kind === "win") playWin();
    }
    if (state.phase === "playing") {
      const sec = Math.ceil(state.remainingMs / 1000);
      if (sec <= 3 && sec > 0 && sec !== lastSecond.current) {
        lastSecond.current = sec;
        playTick();
      }
      if (sec > 3) lastSecond.current = null;
    } else {
      lastSecond.current = null;
    }
  }, [state]);
}
