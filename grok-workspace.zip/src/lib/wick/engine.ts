import {
  FUSE_STEP_MS,
  HOUSE,
  MAX_PLAYERS,
  MIN_FUSE_MS,
  START_FUSE_MS,
  START_LIVES,
  type GameState,
  type Player,
} from "./types";
import { checkWord, pickFragment } from "./words";

function bump(state: GameState, patch: Partial<GameState>): GameState {
  return { ...state, ...patch, eventNonce: state.eventNonce + 1 };
}

function alive(players: readonly Player[]): Player[] {
  return players.filter((p) => !p.out);
}

function nextAlive(players: readonly Player[], currentId: string | null): Player | null {
  const living = alive(players);
  if (living.length === 0) return null;
  if (!currentId) return living[0] ?? null;
  const idx = players.findIndex((p) => p.id === currentId);
  for (let step = 1; step <= players.length; step++) {
    const p = players[(idx + step) % players.length];
    if (p && !p.out) return p;
  }
  return living[0] ?? null;
}

function beginTurn(state: GameState, playerId: string, now: number): GameState {
  const fuseMs = Math.max(MIN_FUSE_MS, START_FUSE_MS - state.round * FUSE_STEP_MS);
  return {
    ...state,
    phase: "playing",
    turnId: playerId,
    fragment: pickFragment(state.usedWords, state.round),
    fuseMs,
    remainingMs: fuseMs,
    turnStartedAt: now,
  };
}

export function createLobby(hostId: string, hostName: string): GameState {
  return {
    phase: "lobby",
    hostId,
    players: [{ id: hostId, name: hostName.trim() || "Guest", isBot: false, lives: START_LIVES, out: false }],
    turnId: null,
    fragment: "",
    remainingMs: START_FUSE_MS,
    fuseMs: START_FUSE_MS,
    usedWords: [],
    lastWord: null,
    lastEvent: null,
    winnerId: null,
    round: 0,
    eventNonce: 0,
  };
}

export function snapshot(state: GameState, now: number): GameState {
  const remainingMs =
    state.phase === "playing" && state.turnStartedAt != null
      ? Math.max(0, state.fuseMs - (now - state.turnStartedAt))
      : state.remainingMs;
  const { turnStartedAt: _, ...rest } = state;
  return { ...rest, remainingMs };
}

export function rehydrateClock(state: GameState, now: number): GameState {
  if (state.phase !== "playing") return { ...state, turnStartedAt: undefined };
  const elapsed = state.fuseMs - state.remainingMs;
  return { ...state, turnStartedAt: now - Math.max(0, elapsed) };
}

export function renamePlayer(state: GameState, id: string, name: string): GameState {
  const next = name.trim().slice(0, 24) || "Guest";
  return {
    ...state,
    players: state.players.map((p) => (p.id === id ? { ...p, name: next } : p)),
  };
}

export function addPlayer(
  state: GameState,
  id: string,
  name: string,
  isBot: boolean,
): GameState {
  if (state.players.some((p) => p.id === id)) {
    return renamePlayer(state, id, name);
  }
  if (state.players.length >= MAX_PLAYERS) return state;
  if (state.phase !== "lobby") return state;
  const player: Player = {
    id,
    name: name.trim().slice(0, 24) || (isBot ? "House" : "Guest"),
    isBot,
    lives: START_LIVES,
    out: false,
  };
  return { ...state, players: [...state.players, player] };
}

export function addHousePlayer(state: GameState): GameState {
  if (state.phase !== "lobby" || state.players.length >= MAX_PLAYERS) return state;
  const taken = new Set(state.players.map((p) => p.id));
  const seat = HOUSE.find((h) => !taken.has(h.id));
  if (!seat) return state;
  return addPlayer(state, seat.id, seat.name, true);
}

export function removePlayer(state: GameState, id: string, now: number): GameState {
  if (state.players.length <= 1) return state;
  const players = state.players.filter((p) => p.id !== id);
  let next: GameState = { ...state, players };
  if (state.hostId === id) {
    const human = players.find((p) => !p.isBot);
    next = { ...next, hostId: human?.id ?? players[0]?.id ?? state.hostId };
  }
  if (next.phase === "playing" && state.turnId === id) {
    return failAndAdvance(next, id, "timeout", now, true);
  }
  if (next.phase === "playing") {
    const living = alive(next.players);
    if (living.length <= 1) {
      return bump(next, {
        phase: "over",
        winnerId: living[0]?.id ?? null,
        turnId: null,
        lastEvent: { kind: "win", playerId: living[0]?.id ?? id },
      });
    }
  }
  return next;
}

export function startMatch(state: GameState, now: number): GameState {
  if (state.phase === "playing") return state;
  if (state.players.length < 2) return state;
  const reset: GameState = {
    ...state,
    phase: "playing",
    players: state.players.map((p) => ({ ...p, lives: START_LIVES, out: false })),
    usedWords: [],
    lastWord: null,
    winnerId: null,
    round: 0,
    lastEvent: { kind: "start", playerId: state.players[0]!.id },
    eventNonce: state.eventNonce + 1,
  };
  const first = reset.players[0];
  if (!first) return state;
  return beginTurn(reset, first.id, now);
}

export function toLobby(state: GameState): GameState {
  return bump(state, {
    phase: "lobby",
    turnId: null,
    fragment: "",
    remainingMs: START_FUSE_MS,
    fuseMs: START_FUSE_MS,
    usedWords: [],
    lastWord: null,
    lastEvent: null,
    winnerId: null,
    round: 0,
    turnStartedAt: undefined,
    players: state.players.map((p) => ({ ...p, lives: START_LIVES, out: false })),
  });
}

function failAndAdvance(
  state: GameState,
  playerId: string,
  kind: "fail" | "timeout",
  now: number,
  alreadyRemoved = false,
): GameState {
  let players = alreadyRemoved
    ? state.players
    : state.players.map((p) => {
        if (p.id !== playerId) return p;
        const lives = Math.max(0, p.lives - 1);
        return { ...p, lives, out: lives <= 0 };
      });
  const victim = players.find((p) => p.id === playerId);
  const living = alive(players);
  if (living.length <= 1) {
    return bump(state, {
      phase: "over",
      players,
      winnerId: living[0]?.id ?? null,
      turnId: null,
      remainingMs: 0,
      lastEvent: { kind: "win", playerId: living[0]?.id ?? playerId },
      turnStartedAt: undefined,
    });
  }
  const next = nextAlive(players, playerId);
  const outNow = Boolean(victim?.out);
  const advanced: GameState = bump(state, {
    players,
    lastEvent: {
      kind: outNow ? "out" : kind,
      playerId,
    },
    round: state.round + 1,
    lastWord: null,
  });
  if (!next) return advanced;
  return beginTurn(advanced, next.id, now);
}

export function submitWord(state: GameState, playerId: string, raw: string, now: number): GameState {
  if (state.phase !== "playing" || state.turnId !== playerId) return state;
  const result = checkWord(raw, state.fragment, state.usedWords);
  if (!result.ok) {
    return failAndAdvance(state, playerId, "fail", now);
  }
  const living = alive(state.players);
  const next = nextAlive(state.players, playerId);
  const advanced: GameState = bump(state, {
    usedWords: [...state.usedWords, result.word],
    lastWord: result.word,
    lastEvent: { kind: "ok", playerId, word: result.word },
    round: state.round + 1,
  });
  if (living.length <= 1 || !next) return advanced;
  return beginTurn(advanced, next.id, now);
}

export function tick(state: GameState, now: number): GameState {
  if (state.phase !== "playing" || state.turnStartedAt == null || !state.turnId) {
    return state;
  }
  const remainingMs = Math.max(0, state.fuseMs - (now - state.turnStartedAt));
  if (remainingMs > 0) {
    if (Math.abs(remainingMs - state.remainingMs) < 32) return state;
    return { ...state, remainingMs };
  }
  return failAndAdvance(state, state.turnId, "timeout", now);
}

export function isYourTurn(state: GameState, selfId: string): boolean {
  return state.phase === "playing" && state.turnId === selfId;
}
