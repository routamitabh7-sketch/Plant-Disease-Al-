import { WORD_LIST } from "./word-list";
import { MAX_WORD, MIN_WORD } from "./types";

/** SEO junk and adult spam that slipped into common-word crawls. */
const DENY = new Set([
  "phentermine",
  "cialis",
  "levitra",
  "tramadol",
  "xanax",
  "ambien",
  "propecia",
  "viagra",
  "spanking",
  "titten",
  "peeing",
  "fetish",
  "lingerie",
  "nude",
  "nudes",
  "porn",
  "xxx",
  "webcam",
  "webcams",
]);

export const WORDS = new Set(WORD_LIST.filter((w) => !DENY.has(w)));

export type WordCheck = { ok: true; word: string } | { ok: false; reason: string };

export function normalizeGuess(raw: string): string {
  return raw.trim().toLowerCase();
}

export function checkWord(
  raw: string,
  fragment: string,
  used: readonly string[],
): WordCheck {
  const word = normalizeGuess(raw);
  if (word.length < MIN_WORD || word.length > MAX_WORD) {
    return { ok: false, reason: `Use ${MIN_WORD}–${MAX_WORD} letters.` };
  }
  if (!/^[a-z]+$/.test(word)) {
    return { ok: false, reason: "Letters only." };
  }
  if (!word.includes(fragment)) {
    return { ok: false, reason: `Must contain ${fragment.toUpperCase()}.` };
  }
  if (word.length <= fragment.length) {
    return { ok: false, reason: "Need a longer word than the letters." };
  }
  if (used.includes(word)) {
    return { ok: false, reason: "Already burned at this table." };
  }
  if (!WORDS.has(word)) {
    return { ok: false, reason: "Not in the house dictionary." };
  }
  return { ok: true, word };
}

function collectFragments(remaining: readonly string[], len: number, minHits: number): string[] {
  const counts = new Map<string, number>();
  for (const w of remaining) {
    for (let i = 0; i <= w.length - len; i++) {
      const f = w.slice(i, i + len);
      counts.set(f, (counts.get(f) ?? 0) + 1);
    }
  }
  return [...counts.entries()].filter(([, c]) => c >= minHits).map(([f]) => f);
}

export function pickFragment(used: readonly string[], round: number): string {
  const usedSet = new Set(used);
  const remaining = WORD_LIST.filter((w) => WORDS.has(w) && !usedSet.has(w));
  const prefer3 = round >= 3;
  const primary = collectFragments(remaining, prefer3 ? 3 : 2, 8);
  const fallback = collectFragments(remaining, prefer3 ? 2 : 3, 6);
  const pool = primary.length >= 6 ? primary : fallback.length ? fallback : primary;
  if (!pool.length) return "er";
  return pool[Math.floor(Math.random() * pool.length)] ?? "er";
}

export function pickBotWord(fragment: string, used: readonly string[]): string | null {
  const usedSet = new Set(used);
  const matches = WORD_LIST.filter(
    (w) => WORDS.has(w) && w.includes(fragment) && w.length > fragment.length && !usedSet.has(w),
  );
  if (!matches.length) return null;
  return matches[Math.floor(Math.random() * matches.length)] ?? null;
}
