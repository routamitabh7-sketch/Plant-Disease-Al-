let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.22;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function unlockAudio(): void {
  const c = getCtx();
  if (c?.state === "suspended") void c.resume();
}

export function setMuted(next: boolean): void {
  muted = next;
  if (master && ctx) {
    master.gain.setTargetAtTime(next ? 0 : 0.22, ctx.currentTime, 0.03);
  }
}

export function isMuted(): boolean {
  return muted;
}

function tone(freq: number, dur: number, type: OscillatorType, gain = 0.18, at = 0) {
  const c = getCtx();
  if (!c || !master) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  const t0 = c.currentTime + at;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g);
  g.connect(master);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
  osc.onended = () => {
    osc.disconnect();
    g.disconnect();
  };
}

function noise(dur: number, gain = 0.12) {
  const c = getCtx();
  if (!c || !master) return;
  const buffer = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource();
  src.buffer = buffer;
  const g = c.createGain();
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = 900;
  const t0 = c.currentTime;
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f);
  f.connect(g);
  g.connect(master);
  src.start(t0);
  src.stop(t0 + dur + 0.02);
}

export function playTick() {
  tone(880 + Math.random() * 40, 0.05, "square", 0.06);
}

export function playType() {
  tone(420 + Math.random() * 80, 0.03, "triangle", 0.05);
}

export function playOk() {
  tone(523, 0.09, "sine", 0.14);
  tone(784, 0.12, "sine", 0.1, 0.07);
}

export function playFail() {
  tone(140, 0.18, "sawtooth", 0.1);
  noise(0.16, 0.08);
}

export function playBoom() {
  noise(0.28, 0.16);
  tone(90, 0.22, "sine", 0.18);
}

export function playWin() {
  tone(523, 0.12, "sine", 0.12);
  tone(659, 0.12, "sine", 0.12, 0.1);
  tone(784, 0.18, "sine", 0.12, 0.2);
}

export function attachUnlockOnce() {
  if (typeof window === "undefined") return;
  const unlock = () => unlockAudio();
  window.addEventListener("pointerdown", unlock, { once: true });
  window.addEventListener("keydown", unlock, { once: true });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") unlockAudio();
  });
}
