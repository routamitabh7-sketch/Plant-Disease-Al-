export type Phase = "lobby" | "playing" | "over";

export type EventKind = "ok" | "fail" | "timeout" | "start" | "out" | "win";

export interface Player {
  id: string;
  name: string;
  isBot: boolean;
  lives: number;
  out: boolean;
}

export interface LastEvent {
  kind: EventKind;
  playerId: string;
  word?: string;
  reason?: string;
}

export interface GameState {
  phase: Phase;
  hostId: string;
  players: Player[];
  turnId: string | null;
  fragment: string;
  remainingMs: number;
  fuseMs: number;
  usedWords: string[];
  lastWord: string | null;
  lastEvent: LastEvent | null;
  winnerId: string | null;
  round: number;
  eventNonce: number;
  /** Host-only clock origin; omitted on the wire. */
  turnStartedAt?: number;
}

export type Wire =
  | { t: "state"; state: GameState }
  | { t: "tick"; remainingMs: number }
  | { t: "submit"; word: string }
  | { t: "addBot" }
  | { t: "removeBot"; id: string }
  | { t: "start" }
  | { t: "again" }
  | { t: "name"; name: string };

export const START_LIVES = 3;
export const START_FUSE_MS = 12_000;
export const MIN_FUSE_MS = 4_500;
export const FUSE_STEP_MS = 280;
export const MAX_PLAYERS = 8;
export const MIN_WORD = 3;
export const MAX_WORD = 12;

export const HOUSE = [
  { id: "b-flint", name: "Flint" },
  { id: "b-ash", name: "Ash" },
  { id: "b-ember", name: "Ember" },
  { id: "b-soot", name: "Soot" },
  { id: "b-match", name: "Match" },
  { id: "b-tinder", name: "Tinder" },
  { id: "b-cinder", name: "Cinder" },
] as const;

/** Thinking window as a fraction of the current fuse, min–max. */
export const BOT_PACE: Record<string, readonly [number, number]> = {
  Flint: [0.28, 0.46],
  Ash: [0.38, 0.58],
  Ember: [0.48, 0.7],
  Soot: [0.34, 0.55],
  Match: [0.3, 0.5],
  Tinder: [0.42, 0.64],
  Cinder: [0.4, 0.62],
};
