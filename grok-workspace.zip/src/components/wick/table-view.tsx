import { Check, Copy, Link2, Minus, Plus, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FuseDial } from "@/components/wick/fuse-dial";
import { WickMark } from "@/components/wick/wick-mark";
import { checkWord } from "@/lib/wick/words";
import { loadMuted, saveMuted } from "@/lib/wick/identity";
import { setMuted as setAudioMuted } from "@/lib/wick/audio";
import type { GameState, Player } from "@/lib/wick/types";
import { MAX_PLAYERS } from "@/lib/wick/types";
import { cn } from "@/lib/utils";

export interface SeatInfo {
  id: string;
  connectionState?: string;
  rttMs?: number | null;
}

export function TableView({
  state,
  selfId,
  isHost,
  roomCode,
  seats,
  connecting,
  onSubmit,
  onStart,
  onAddBot,
  onRemoveBot,
  onAgain,
}: {
  state: GameState;
  selfId: string;
  isHost: boolean;
  roomCode?: string;
  seats?: SeatInfo[];
  connecting?: boolean;
  onSubmit: (word: string) => void;
  onStart: () => void;
  onAddBot: () => void;
  onRemoveBot: (id: string) => void;
  onAgain: () => void;
}) {
  const you = state.players.find((p) => p.id === selfId);
  const yourTurn = state.phase === "playing" && state.turnId === selfId;
  const current = state.players.find((p) => p.id === state.turnId);
  const winner = state.players.find((p) => p.id === state.winnerId);
  const hot = state.phase === "playing" && state.remainingMs / state.fuseMs < 0.28;
  const boom =
    state.lastEvent?.kind === "timeout" ||
    state.lastEvent?.kind === "fail" ||
    state.lastEvent?.kind === "out";
  const [copied, setCopied] = useState(false);
  const [guess, setGuess] = useState("");
  const [hint, setHint] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const initial = loadMuted();
    setMuted(initial);
    setAudioMuted(initial);
  }, []);

  useEffect(() => {
    if (yourTurn) inputRef.current?.focus();
    else setGuess("");
  }, [yourTurn, state.turnId]);

  useEffect(() => {
    setHint(null);
    setGuess("");
  }, [state.eventNonce]);

  const seatMap = useMemo(() => new Map((seats ?? []).map((s) => [s.id, s])), [seats]);

  async function copyInvite() {
    if (!roomCode) return;
    const url = `${window.location.origin}/play?room=${roomCode}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!yourTurn) return;
    const result = checkWord(guess, state.fragment, state.usedWords);
    if (!result.ok) {
      setHint(result.reason);
      return;
    }
    onSubmit(result.word);
    setGuess("");
    setHint(null);
  }

  return (
    <div
      className={cn(
        "relative mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4 pb-8 pt-5 sm:px-6",
        boom && "wick-shake",
      )}
    >
      {boom ? (
        <div className="wick-flash pointer-events-none absolute inset-0 bg-fuse/30" />
      ) : null}

      <header className="flex items-center justify-between gap-3">
        <Link to="/" className="flex items-center gap-2 text-fg">
          <WickMark className="h-8 w-4" />
          <span className="font-display text-xl italic">Wick</span>
        </Link>
        <div className="flex items-center gap-1">
          {roomCode ? (
            <Button variant="ghost" size="icon" onClick={() => void copyInvite()} aria-label="Copy invite">
              {copied ? <Check className="size-4" /> : <Link2 className="size-4" />}
            </Button>
          ) : null}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              const next = !muted;
              setMuted(next);
              saveMuted(next);
              setAudioMuted(next);
            }}
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </Button>
        </div>
      </header>

      {roomCode ? (
        <div className="mt-5 rounded-xl border border-border bg-surface px-4 py-4">
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Table</p>
          <div className="mt-1 flex items-end justify-between gap-3">
            <p className="font-display text-4xl tracking-code text-fg">{roomCode}</p>
            <Button variant="secondary" size="sm" onClick={() => void copyInvite()}>
              {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              {copied ? "Copied" : "Copy link"}
            </Button>
          </div>
        </div>
      ) : (
        <p className="mt-5 text-sm text-muted">Practice table · house players</p>
      )}

      {connecting ? (
        <p className="mt-4 text-sm text-muted">Taking a seat…</p>
      ) : null}

      <ul className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
        {state.players.map((p) => (
          <SeatCard
            key={p.id}
            player={p}
            selfId={selfId}
            current={state.turnId === p.id && state.phase === "playing"}
            winner={state.phase === "over" && state.winnerId === p.id}
            conn={seatMap.get(p.id)}
            canRemove={isHost && state.phase === "lobby" && p.isBot}
            onRemove={() => onRemoveBot(p.id)}
          />
        ))}
      </ul>

      {state.phase === "lobby" ? (
        <LobbyPanel
          isHost={isHost}
          canStart={state.players.length >= 2}
          canAdd={state.players.length < MAX_PLAYERS}
          onStart={onStart}
          onAddBot={onAddBot}
        />
      ) : null}

      {state.phase === "playing" ? (
        <div className="mt-8 flex flex-1 flex-col">
          <FuseDial
            remainingMs={state.remainingMs}
            fuseMs={state.fuseMs}
            fragment={state.fragment}
            hot={hot}
          />
          <p className="mt-4 text-center text-sm text-muted">
            {yourTurn
              ? "Your wick. Type a word that contains those letters."
              : `${current?.name ?? "Someone"} is writing.`}
          </p>
          {state.lastWord ? (
            <p className="mt-1 text-center font-display text-lg italic text-fg/80">
              {state.lastWord}
            </p>
          ) : null}

          <form
            onSubmit={handleSubmit}
            className="sticky bottom-0 mt-auto flex flex-col gap-2 bg-bg/95 pt-6 pb-[max(0.5rem,env(safe-area-inset-bottom))]"
          >
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={guess}
                onChange={(e) => {
                  setGuess(e.target.value);
                  setHint(null);
                }}
                placeholder={yourTurn ? "a word…" : "waiting"}
                autoCapitalize="none"
                autoCorrect="off"
                autoComplete="off"
                spellCheck={false}
                disabled={!yourTurn}
                aria-label="Word"
                className="font-display text-xl italic tracking-wide"
              />
              <Button type="submit" disabled={!yourTurn || guess.trim().length < 3}>
                Send
              </Button>
            </div>
            <p className="min-h-5 text-sm text-fuse">{hint ?? " "}</p>
          </form>
        </div>
      ) : null}

      {state.phase === "over" ? (
        <div className="mt-10 flex flex-1 flex-col items-center text-center">
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Last wick lit</p>
          <h2 className="mt-2 font-display text-4xl italic text-fg">
            {winner?.id === selfId ? "You held." : `${winner?.name ?? "Someone"} held.`}
          </h2>
          <p className="mt-2 max-w-sm text-sm text-muted">
            {state.usedWords.length} words burned
            {you ? ` · you left with ${you.lives} ${you.lives === 1 ? "life" : "lives"}` : null}
          </p>
          <div className="mt-8 flex w-full max-w-xs flex-col gap-2">
            <Button onClick={onAgain} size="lg" disabled={Boolean(roomCode) && !isHost}>
              <RotateCcw className="size-4" />
              {roomCode && !isHost ? "Wait for host" : "Again"}
            </Button>
            <Button variant="secondary" asChild>
              <Link to="/">Leave table</Link>
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function SeatCard({
  player,
  selfId,
  current,
  winner,
  conn,
  canRemove,
  onRemove,
}: {
  player: Player;
  selfId: string;
  current: boolean;
  winner: boolean;
  conn?: SeatInfo;
  canRemove: boolean;
  onRemove: () => void;
}) {
  const you = player.id === selfId;
  const failed = conn?.connectionState === "failed";
  return (
    <li
      className={cn(
        "flex items-center gap-3 rounded-lg border px-3 py-3",
        current || winner
          ? "border-accent/50 bg-elevated"
          : "border-border bg-surface",
        player.out && "opacity-45",
      )}
    >
      <div
        className={cn(
          "grid size-9 shrink-0 place-items-center rounded-sm border text-sm font-medium",
          current ? "border-accent text-fg" : "border-border text-muted",
        )}
        aria-hidden
      >
        {player.name.slice(0, 1).toUpperCase()}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-fg">
          {player.name}
          {you ? <span className="ml-2 text-xs font-normal text-muted">you</span> : null}
          {player.isBot ? <span className="ml-2 text-xs font-normal text-muted">house</span> : null}
        </p>
        <p className="text-xs text-subtle">
          {failed
            ? "Can't reach"
            : player.out
              ? "Burned out"
              : current
                ? "Writing"
                : winner
                  ? "Held"
                  : player.isBot
                    ? "House"
                    : conn?.connectionState === "connected"
                      ? "Seated"
                      : conn?.connectionState
                        ? "Joining"
                        : "Seated"}
        </p>
      </div>
      <Lives lives={player.lives} />
      {canRemove ? (
        <Button variant="ghost" size="icon" className="size-9 min-h-9" onClick={onRemove} aria-label={`Remove ${player.name}`}>
          <Minus className="size-4" />
        </Button>
      ) : null}
    </li>
  );
}

function Lives({ lives }: { lives: number }) {
  return (
    <div className="flex gap-1" aria-label={`${lives} lives`}>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className={cn("h-4 w-1 rounded-full", i < lives ? "bg-live" : "bg-border")}
        />
      ))}
    </div>
  );
}

function LobbyPanel({
  isHost,
  canStart,
  canAdd,
  onStart,
  onAddBot,
}: {
  isHost: boolean;
  canStart: boolean;
  canAdd: boolean;
  onStart: () => void;
  onAddBot: () => void;
}) {
  return (
    <div className="mt-8 flex flex-1 flex-col">
      <p className="max-w-md text-sm leading-relaxed text-muted">
        A cluster of letters appears. Type a real word that contains them before the fuse dies.
        Three lives. Last wick lit wins.
      </p>
      <div className="mt-auto flex flex-col gap-2 pt-8">
        {isHost ? (
          <>
            <Button size="lg" onClick={onStart} disabled={!canStart}>
              Light the fuse
            </Button>
            <Button variant="secondary" onClick={onAddBot} disabled={!canAdd}>
              <Plus className="size-4" />
              Seat a house player
            </Button>
            {!canStart ? (
              <p className="text-center text-sm text-subtle">
                Need two at the table. Share the code, or seat the house.
              </p>
            ) : null}
          </>
        ) : (
          <p className="text-center text-sm text-muted">Waiting for the host to light the fuse.</p>
        )}
      </div>
    </div>
  );
}
