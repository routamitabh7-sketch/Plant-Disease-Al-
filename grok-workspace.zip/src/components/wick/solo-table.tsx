import { useCallback, useEffect, useRef, useState } from "react";
import { TableView } from "@/components/wick/table-view";
import {
  addHousePlayer,
  createLobby,
  removePlayer,
  snapshot,
  startMatch,
  submitWord,
  tick,
  toLobby,
} from "@/lib/wick/engine";
import { pickBotWord } from "@/lib/wick/words";
import { BOT_PACE, type GameState } from "@/lib/wick/types";
import { useWickJuice } from "@/lib/wick/juice";

const SELF = "you";

export function SoloTable({ name }: { name: string }) {
  const engine = useRef<GameState | null>(null);
  const [view, setView] = useState<GameState | null>(null);

  const publish = useCallback((s: GameState) => {
    engine.current = s;
    setView(snapshot(s, performance.now()));
  }, []);

  useEffect(() => {
    let s = createLobby(SELF, name);
    s = addHousePlayer(s);
    s = addHousePlayer(s);
    s = addHousePlayer(s);
    s = startMatch(s, performance.now());
    publish(s);
  }, [name, publish]);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const s = engine.current;
      if (s) {
        const next = tick(s, performance.now());
        if (next !== s) publish(next);
        else setView(snapshot(next, performance.now()));
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [publish]);

  useEffect(() => {
    const s = engine.current;
    if (!s || s.phase !== "playing" || !s.turnId) return;
    const actor = s.players.find((p) => p.id === s.turnId);
    if (!actor?.isBot) return;
    const [min, max] = BOT_PACE[actor.name] ?? [0.4, 0.6];
    const delay = s.fuseMs * (min + Math.random() * (max - min));
    const handle = window.setTimeout(() => {
      const cur = engine.current;
      if (!cur || cur.turnId !== actor.id) return;
      const word = pickBotWord(cur.fragment, cur.usedWords);
      if (word) publish(submitWord(cur, actor.id, word, performance.now()));
    }, delay);
    return () => window.clearTimeout(handle);
  }, [view?.turnId, view?.eventNonce, publish]);

  useWickJuice(view);

  if (!view) {
    return (
      <div className="grid min-h-dvh place-items-center text-sm text-muted">Lighting the fuse…</div>
    );
  }

  return (
    <TableView
      state={view}
      selfId={SELF}
      isHost
      onSubmit={(word) => {
        const s = engine.current;
        if (!s) return;
        publish(submitWord(s, SELF, word, performance.now()));
      }}
      onStart={() => {
        const s = engine.current;
        if (!s) return;
        publish(startMatch(s, performance.now()));
      }}
      onAddBot={() => {
        const s = engine.current;
        if (!s) return;
        publish(addHousePlayer(s));
      }}
      onRemoveBot={(id) => {
        const s = engine.current;
        if (!s) return;
        publish(removePlayer(s, id, performance.now()));
      }}
      onAgain={() => {
        const s = engine.current;
        if (!s) return;
        publish(startMatch(toLobby(s), performance.now()));
      }}
    />
  );
}
