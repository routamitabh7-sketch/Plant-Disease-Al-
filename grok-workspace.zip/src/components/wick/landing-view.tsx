import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WickMark } from "@/components/wick/wick-mark";
import { attachUnlockOnce, unlockAudio } from "@/lib/wick/audio";
import { loadName, makeTableCode, sanitizeCode, saveName } from "@/lib/wick/identity";

export function LandingView() {
  const navigate = useNavigate();
  const [name, setName] = useState("Guest");
  const [code, setCode] = useState("");
  const [joinError, setJoinError] = useState<string | null>(null);

  useEffect(() => {
    setName(loadName());
    attachUnlockOnce();
  }, []);

  function persist() {
    const next = name.trim().slice(0, 24) || "Guest";
    setName(next);
    saveName(next);
    unlockAudio();
    return next;
  }

  function createTable() {
    persist();
    const table = makeTableCode();
    void navigate({ to: "/play", search: { room: table } });
  }

  function practice() {
    persist();
    void navigate({ to: "/play", search: { solo: true } });
  }

  function joinTable(e: FormEvent) {
    e.preventDefault();
    const next = sanitizeCode(code);
    if (next.length !== 4) {
      setJoinError("Enter the four-character table code.");
      return;
    }
    persist();
    void navigate({ to: "/play", search: { room: next } });
  }

  return (
    <main className="relative mx-auto flex min-h-dvh w-full max-w-lg flex-col px-5 py-8 sm:px-6">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 wick-wash" aria-hidden />

      <div className="relative flex flex-1 flex-col">
        <WickMark className="h-12 w-6" />
        <h1 className="mt-6 font-display text-6xl font-medium italic leading-none tracking-tight text-fg sm:text-7xl">
          Wick
        </h1>
        <p className="mt-4 max-w-sm text-base leading-relaxed text-muted">
          A word, before it burns. Sit a table with friends, or practice against the house.
        </p>

        <label className="mt-10 text-xs font-medium tracking-widest text-muted uppercase" htmlFor="wick-name">
          Your name
        </label>
        <Input
          id="wick-name"
          className="mt-2"
          value={name}
          maxLength={24}
          onChange={(e) => setName(e.target.value)}
          autoComplete="nickname"
        />

        <div className="mt-6 flex flex-col gap-2">
          <Button size="lg" onClick={createTable}>
            Create a table
          </Button>
          <Button size="lg" variant="secondary" onClick={practice}>
            Practice with the house
          </Button>
        </div>

        <form onSubmit={joinTable} className="mt-10">
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Join with a code</p>
          <div className="mt-2 flex gap-2">
            <Input
              value={code}
              onChange={(e) => {
                setCode(sanitizeCode(e.target.value));
                setJoinError(null);
              }}
              placeholder="A7KM"
              autoCapitalize="characters"
              autoCorrect="off"
              spellCheck={false}
              aria-label="Table code"
              className="font-display tracking-code uppercase"
            />
            <Button type="submit" variant="secondary">
              Sit
            </Button>
          </div>
          <p className="mt-2 min-h-5 text-sm text-fuse">{joinError ?? " "}</p>
        </form>

        <ol className="mt-auto space-y-3 pt-10 text-sm leading-relaxed text-muted">
          <li>
            <span className="text-fg">1.</span> Letters appear in the ring.
          </li>
          <li>
            <span className="text-fg">2.</span> Type a dictionary word that contains them.
          </li>
          <li>
            <span className="text-fg">3.</span> Miss and you lose a life. Last wick lit wins.
          </li>
        </ol>
      </div>
    </main>
  );
}
