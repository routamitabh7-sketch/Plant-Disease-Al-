import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useP2PRoom } from "@/lib/multiplayer";
import { TableView } from "@/components/wick/table-view";
import {
  addHousePlayer,
  addPlayer,
  createLobby,
  rehydrateClock,
  removePlayer,
  snapshot,
  startMatch,
  submitWord,
  tick,
  toLobby,
} from "@/lib/wick/engine";
import { pickBotWord } from "@/lib/wick/words";
import { BOT_PACE, type GameState, type Wire } from "@/lib/wick/types";
import { roomIdForCode } from "@/lib/wick/identity";
import { useWickJuice } from "@/lib/wick/juice";

function isWire(value: unknown): value is Wire {
  return Boolean(value) && typeof value === "object" && "t" in (value as object);
}

export function FriendsTable({ code, name }: { code: string; name: string }) {
  const p2p = useP2PRoom({ room: roomIdForCode(code), name });
  const engine = useRef<GameState | null>(null);
  const viewRef = useRef<GameState | null>(null);
  const seen = useRef(new Set<string>());
  const [view, setView] = useState<GameState | null>(null);
  viewRef.current = view;

  const livePeers = useMemo(
    () => p2p.peers.filter((p) => p.connectionState !== "failed" && p.connectionState !== "closed"),
    [p2p.peers],
  );
  const authorityId = useMemo(() => {
    const ids = [p2p.selfId, ...livePeers.map((p) => p.id)].sort();
    return ids[0] ?? p2p.selfId;
  }, [p2p.selfId, livePeers]);
  const isHost = authorityId === p2p.selfId;

  const publish = useCallback(
    (s: GameState, reliable = true) => {
      engine.current = s;
      const snap = snapshot(s, performance.now());
      setView(snap);
      if (reliable) p2p.send({ t: "state", state: snap });
      else p2p.broadcast({ t: "tick", remainingMs: snap.remainingMs });
    },
    [p2p.send, p2p.broadcast],
  );

  useEffect(() => {
    if (!p2p.joined) return;
    if (!isHost) {
      engine.current = null;
      return;
    }
    if (engine.current) return;
    const wait = window.setTimeout(() => {
      if (engine.current) return;
      const base = viewRef.current
        ? rehydrateClock(viewRef.current, performance.now())
        : createLobby(p2p.selfId, name);
      engine.current = { ...base, hostId: p2p.selfId };
      publish(engine.current);
    }, 450);
    return () => window.clearTimeout(wait);
  }, [isHost, p2p.joined, p2p.selfId, name, publish]);

  useEffect(() => {
    const newcomers = p2p.peers.filter((p) => !seen.current.has(p.id));
    const existing = [p2p.selfId, ...seen.current].sort();
    if (engine.current && newcomers.length && existing[0] === p2p.selfId) {
      const snap = snapshot(engine.current, performance.now());
      for (const n of newcomers) p2p.send({ t: "state", state: snap }, n.id);
    }
    seen.current = new Set(p2p.peers.map((p) => p.id));
  }, [p2p.peers, p2p.selfId, p2p.send]);

  useEffect(() => {
    if (!isHost || !engine.current) return;
    let s = engine.current;
    let changed = false;
    for (const peer of p2p.peers) {
      if (!s.players.some((p) => p.id === peer.id)) {
        s = addPlayer(s, peer.id, peer.name || "Guest", false);
        changed = true;
      }
    }
    for (const player of [...s.players]) {
      if (player.isBot || player.id === p2p.selfId) continue;
      if (!p2p.peers.some((peer) => peer.id === player.id)) {
        s = removePlayer(s, player.id, performance.now());
        changed = true;
      }
    }
    if (changed) publish(s);
  }, [isHost, p2p.peers, p2p.selfId, publish, view?.phase]);

  useEffect(() => {
    return p2p.onMessage((from, data) => {
      if (!isWire(data)) return;
      if (data.t === "state") {
        if (!isHost) setView(data.state);
        return;
      }
      if (data.t === "tick") {
        if (!isHost) {
          setView((prev) => (prev ? { ...prev, remainingMs: data.remainingMs } : prev));
        }
        return;
      }
      if (!isHost || !engine.current) return;
      const now = performance.now();
      if (data.t === "submit") publish(submitWord(engine.current, from, data.word, now));
      if (data.t === "start") publish(startMatch(engine.current, now));
      if (data.t === "addBot") publish(addHousePlayer(engine.current));
      if (data.t === "removeBot") publish(removePlayer(engine.current, data.id, now));
      if (data.t === "again") publish(toLobby(engine.current));
    });
  }, [isHost, p2p.onMessage, publish]);

  useEffect(() => {
    if (!isHost) return;
    let raf = 0;
    let lastEmit = 0;
    const loop = (now: number) => {
      const s = engine.current;
      if (s) {
        const next = tick(s, now);
        const nonceChanged = next.eventNonce !== s.eventNonce;
        engine.current = next;
        const snap = snapshot(next, now);
        setView(snap);
        if (nonceChanged) {
          p2p.send({ t: "state", state: snap });
        } else if (now - lastEmit > 140 && next.phase === "playing") {
          lastEmit = now;
          p2p.broadcast({ t: "tick", remainingMs: snap.remainingMs });
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [isHost, p2p.send, p2p.broadcast]);

  useEffect(() => {
    if (!isHost) return;
    const s = engine.current;
    if (!s || s.phase !== "playing" || !s.turnId) return;
    const actor = s.players.find((p) => p.id === s.turnId);
    if (!actor?.isBot) return;
    const [min, max] = BOT_PACE[actor.name] ?? [0.4, 0.6];
    const delay = s.fuseMs * (min + Math.random() * (max - min));
    const handle = window.setTimeout(() => {
      const cur = engine.current;
      if (!cur || cur.turnId !== actor.id) return;
      const word = pickBotWord(cur.fragment, cur.usedWords);
      if (word) publish(submitWord(cur, actor.id, word, performance.now()));
    }, delay);
    return () => window.clearTimeout(handle);
  }, [isHost, view?.turnId, view?.eventNonce, publish]);

  useWickJuice(view);

  const sendOrDo = (local: (s: GameState) => GameState, remote: Wire) => {
    if (isHost && engine.current) publish(local(engine.current));
    else p2p.send(remote);
  };

  if (!view) {
    return (
      <div className="grid min-h-dvh place-items-center px-6 text-center">
        <p className="text-sm text-muted">Taking a seat at {code}…</p>
      </div>
    );
  }

  return (
    <TableView
      state={view}
      selfId={p2p.selfId}
      isHost={isHost}
      roomCode={code}
      connecting={!p2p.joined}
      seats={p2p.peers.map((p) => ({
        id: p.id,
        connectionState: p.connectionState,
        rttMs: p.rttMs,
      }))}
      onSubmit={(word) =>
        sendOrDo((s) => submitWord(s, p2p.selfId, word, performance.now()), { t: "submit", word })
      }
      onStart={() => sendOrDo((s) => startMatch(s, performance.now()), { t: "start" })}
      onAddBot={() => sendOrDo((s) => addHousePlayer(s), { t: "addBot" })}
      onRemoveBot={(id) => sendOrDo((s) => removePlayer(s, id, performance.now()), { t: "removeBot", id })}
      onAgain={() => sendOrDo((s) => toLobby(s), { t: "again" })}
    />
  );
}
