import { cn } from "@/lib/utils";

export function WickMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 40"
      aria-hidden="true"
      className={cn("text-accent", className)}
    >
      <path
        d="M12 38 V14"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M12 14 C12 10 9.5 8 10 5 C11.5 7 13.5 6.5 14 4 C15.5 8 12 10 12 14 Z"
        fill="currentColor"
        className="text-fuse"
      />
    </svg>
  );
}
