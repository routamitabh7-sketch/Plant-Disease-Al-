import { cn } from "@/lib/utils";

export function FuseDial({
  remainingMs,
  fuseMs,
  fragment,
  hot,
}: {
  remainingMs: number;
  fuseMs: number;
  fragment: string;
  hot: boolean;
}) {
  const t = fuseMs <= 0 ? 0 : Math.max(0, Math.min(1, remainingMs / fuseMs));
  const r = 88;
  const c = 2 * Math.PI * r;
  const dash = c * t;
  const seconds = Math.max(0, remainingMs / 1000);

  return (
    <div className="relative mx-auto grid place-items-center">
      <svg
        viewBox="0 0 200 200"
        className={cn("size-64 sm:size-72", hot && "wick-hot")}
        aria-hidden="true"
      >
        <circle
          cx="100"
          cy="100"
          r={r}
          fill="none"
          className="text-border"
          stroke="currentColor"
          strokeWidth="1.5"
        />
        <circle
          cx="100"
          cy="100"
          r={r}
          fill="none"
          className={hot ? "text-fuse" : "text-accent"}
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${c}`}
          transform="rotate(-90 100 100)"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 px-6 text-center">
        <p className="font-display text-4xl font-medium tracking-wide text-fg sm:text-5xl">
          {fragment.toUpperCase()}
        </p>
        <p className="text-xs tabular-nums tracking-widest text-muted">
          {seconds.toFixed(1)}s
        </p>
      </div>
    </div>
  );
}
