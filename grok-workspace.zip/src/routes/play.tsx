import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { FriendsTable } from "@/components/wick/friends-table";
import { SoloTable } from "@/components/wick/solo-table";
import { loadName, sanitizeCode } from "@/lib/wick/identity";
import { attachUnlockOnce } from "@/lib/wick/audio";
import { Button } from "@/components/ui/button";

type PlaySearch = {
  room?: string;
  solo?: boolean;
};

export const Route = createFileRoute("/play")({
  validateSearch: (raw: Record<string, unknown>): PlaySearch => {
    const roomRaw = typeof raw.room === "string" ? sanitizeCode(raw.room) : "";
    const solo = raw.solo === true || raw.solo === "true" || raw.solo === "1";
    return {
      room: roomRaw.length === 4 ? roomRaw : undefined,
      solo: solo || undefined,
    };
  },
  component: PlayPage,
});

function PlayPage() {
  const { room, solo } = Route.useSearch();
  const [name, setName] = useState<string | null>(null);

  useEffect(() => {
    setName(loadName());
    attachUnlockOnce();
  }, []);

  if (!room && !solo) {
    return (
      <main className="grid min-h-dvh place-items-center px-6 text-center">
        <div>
          <p className="text-muted">No table here.</p>
          <Button asChild className="mt-4">
            <Link to="/">Back</Link>
          </Button>
        </div>
      </main>
    );
  }

  if (!name) {
    return (
      <div className="grid min-h-dvh place-items-center text-sm text-muted">Taking a seat…</div>
    );
  }

  if (solo) return <SoloTable name={name} />;
  if (room) return <FriendsTable key={room} code={room} name={name} />;
  return null;
}
